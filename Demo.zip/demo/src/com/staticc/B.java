package com.staticc;

public class B {
int a=5;
static int b=10;

B(){
	++a;
	++b;
}
void m1(){
	++a;
	++b;
	System.out.println(a+" "+b);
}
public static void main(String[] args) {
	System.out.println(B.b);
	
	B obj = new B();
	obj.m1();
	obj.m1();
	
	B obj1 = new B();
	obj1.m1();
	obj1.m1();
	
	B obj2 = new B();
	obj2.m1();
	obj2.m1();
	
	System.out.println(B.b);
	
}
}
