package com.staticc;

public class D {
	int a =5;
	static int b =1;
	static final int c=10;
   
	D(){
		System.out.println(a+b+c);
		}
	final void m1(){
		System.out.println(a);
		System.out.println(b);
		System.out.println(c);
	}
	
	
	public static void main(String[] args) {
		D obj = new D();
		obj.m1();
		System.out.println(D.b);
		System.out.println(D.c);
		
	}
}
