package com.staticc;

public class A {
	int x=5;
	static int y = 10;
	A(){
		
		++x;
		++y;
		System.out.println(x+" "+y);
	}
public static void main(String[] args) {
	System.out.println(A.y);
	A obj = new A();
	A obj1 = new A();
	A obj2 = new A();
	
	System.out.println(A.y);
	
}	
}


