package com.staticc;

public class C {
	
	static class Xyz{
	static{
		System.out.println("hello");
	}	
	{
		System.out.println("bye");
	}
	void m5(){
		System.out.println("okkk");
	}
		
	}
	static int a=5;
	int b=10;
	
	void m2(){
		System.out.println(a);
		System.out.println(b);
		m1();
	}
	

	static{
		System.out.println("at static 2");
	}
	{
		System.out.println("at instance block12");
	}
	
	static void m1(){
		System.out.println(a);
		//System.out.println(b);
		System.out.println("at method ");
		//m2();
	}
	 C(){

		System.out.println("at constructor");
		
	}
	static {
		System.out.println("at static 1");
	}
	{
		System.out.println("at instance block2");
	}
	
	
	public static void main(String[] args) {
		C obj = new C();
		C.m1();
		obj.m1();
		obj.m2();
		
		
		C obj1 = new C();
		Xyz ref = new Xyz();
		
	}

}
