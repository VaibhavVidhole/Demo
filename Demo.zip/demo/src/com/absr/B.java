package com.absr;

public class B extends A {
	int t = 6;
	@Override
	void m1(){
		System.out.println("bm1");
	}
	
	@Override
	void m2(){
		System.out.println("bm2");
	}
	
	@Override
	void m3(){
		System.out.println("bm3");
	}
	
	//abstract void m4();
	
	void m5(){
		System.out.println("bm5");
	}
	

}
