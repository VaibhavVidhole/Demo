package com.absr;

public class TestABC {
		
	
	public static void main(String[] args) {
		A obj = new C();
		System.out.println(obj.t);
		obj.m1();
		obj.m2();
		obj.m3();
		}

}
