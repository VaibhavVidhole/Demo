package com.absr;

public abstract class A {
	int t=5;
	abstract void m1();
	abstract void m2();
	
	void m3(){
		
		System.out.println("m3");
	}

}
