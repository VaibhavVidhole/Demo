package com.absr;
public class C extends B {
	@Override
	void m1(){
		System.out.println("cm1");
	}
	@Override
	void m2(){
		System.out.println("cm2");
	}
	
	@Override
	void m3(){
		System.out.println("cm3");
	}
	
	@Override
	void m5(){
		System.out.println("cm5");
	
}
}