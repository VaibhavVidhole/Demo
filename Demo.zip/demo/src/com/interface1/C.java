package com.interface1;

public class C {
	int a=6;
	void m7(){
		System.out.println("cm7");
	}
	
	void m8(){
		System.out.println("cm8");
	}
	
	void m9(){
		System.out.println("cm9");
	}

}
