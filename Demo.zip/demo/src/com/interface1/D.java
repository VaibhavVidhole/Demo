package com.interface1;

public class D extends C implements A,B{
	public void m1(){
		System.out.println("m1");
	}
	public void m2(){
		System.out.println("m2");
	}
	public void m3(){
		System.out.println("m3");
	}
	public void m4(){
		System.out.println("m4");
	}
	public void m5(){
		System.out.println("m5");
	}
	public void m6(){
		System.out.println("m6");
	}
	@Override
	void m7(){
		System.out.println("dm7");
	}
	@Override
	void m8(){
		System.out.println("dm8");
	}
	@Override
	void m9(){
		System.out.println("dm9");
	}
	public void m100(){}
	
}
