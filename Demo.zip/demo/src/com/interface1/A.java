package com.interface1;

public interface A {
	int a=5;
	void m1();
	void m2();
	void m3();
	void m100();
}
