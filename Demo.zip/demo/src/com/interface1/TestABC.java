package com.interface1;

public class TestABC {
	public static void main(String[] args) {
		A ref = new D();
		ref.m1();
		ref.m2();
		ref.m3();
		System.out.println(ref.a);
	}
	
	

}
