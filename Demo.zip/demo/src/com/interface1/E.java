package com.interface1;

public interface E extends A,B{
	void m1();
	void m2();
	void m3();
	void m4();
	void m5();
	void m6();

}
