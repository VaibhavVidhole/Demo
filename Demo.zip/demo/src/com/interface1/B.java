package com.interface1;

public interface B {
	int a=7;
void m4();
void m5();
void m6();
void m100();

}
