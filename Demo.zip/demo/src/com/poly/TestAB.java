package com.poly;

public class TestAB {
	public static void main(String[] args) {
		A ref = new A();
		ref.m1();
		System.out.println(ref.a);
		System.out.println("==========");
		A ref1 = new B();
		ref1.m1();
		System.out.println(ref1.a);
		System.out.println("======");
		
		B ref2 = new B();
		ref2.m1();
		System.out.println(ref2.a);
		
	}
	
}
