package com.poly;

public class B extends A{
	int a=10;
	public  void m1(){
		System.out.println("at B class");
	}


}
