package com.poly;

public class A {
	int a= 5;
	protected void m1(){
		System.out.println("at A class");
		
	}

}
